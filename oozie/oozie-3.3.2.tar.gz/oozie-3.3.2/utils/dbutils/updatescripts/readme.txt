dbscripts-3.0.0.sql will be used to create all the tables if we have new schema.

updatescripts-2.x-to-3.0.0.sql will be used to update the tables from 2.x to 3.0.0.

upgradescript-2.x-to-3.0.0.sql will be used to change the previous statuses to new statuses when we will update the current running system of 2.x to 3.0.0

For all the scripts please change the db name and run the script.
