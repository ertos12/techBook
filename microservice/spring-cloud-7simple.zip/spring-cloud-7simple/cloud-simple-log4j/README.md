### 基本用法 

-------------------
spring boot或者spring cloud使用log4j及输出tomcat日志demo！

-------------------
-------------------


