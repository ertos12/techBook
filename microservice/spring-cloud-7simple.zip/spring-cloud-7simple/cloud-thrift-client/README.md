## Spring cloud 7day simple

**spring boot + thrift +zookeeper。

-------------------
功能：
* 1）使用thrift进行通信。
* 2）使用zookeeper实现负载均衡

-------------------
### 开发环境
* IDE：myeclipse 10
* JDK：jdk1.7
* WINDOWS：mvn 3

-------------------
-------------------


