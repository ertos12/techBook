package com.didispace.service.impl;

import com.didispace.service.ComputeService;

/**
 * Created by zhaiyc on 2016/7/14.
 */
public class ComputeServiceImpl implements ComputeService {

    @Override
    public Integer add(int a, int b) {
        return a + b;
    }

}
