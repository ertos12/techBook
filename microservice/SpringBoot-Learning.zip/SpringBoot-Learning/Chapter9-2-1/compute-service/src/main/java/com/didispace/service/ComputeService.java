package com.didispace.service;

/**
 * Created by zhaiyc on 2016/7/14.
 */
public interface ComputeService {

    Integer add(int a, int b);

}
