package com.didispace.exception;

/**
 * @author 程序猿DD
 * @version 1.0.0
 * @date 16/5/2 上午10:50.
 * @blog http://blog.didispace.com
 */
public class MyException extends Exception {

    public MyException(String message) {
        super(message);
    }

}
