# Make sure file is there to be read
hadoop SequenceFileWriteDemo numbers.seq