kube-scheduler --master 127.0.0.1:8080 \
--v=0 \
--logtostderr=false \
--log_dir=./log &
