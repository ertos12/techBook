kube-controller-manager --master 127.0.0.1:8080 \
--cloud-provider="" \
--v=0 \
--logtostderr=false \
--log_dir=./log &
