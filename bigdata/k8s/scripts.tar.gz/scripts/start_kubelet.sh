kubelet \
--address=127.0.0.1 \
--api-servers=127.0.0.1:8080 \
--port=10250 \
--hostname_override=127.0.0.1 \
--v=0 \
--logtostderr=true \
--log_dir=./log &
