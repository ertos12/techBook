kube-proxy \
--master=http://127.0.0.1:8080 \
--v=0 \
--logtostderr=true \
--log_dir=./log &
