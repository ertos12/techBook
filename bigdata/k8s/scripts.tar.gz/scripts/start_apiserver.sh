kube-apiserver \
--bind-address=0.0.0.0 \
--insecure-port=8080 \
--service-cluster-ip-range=192.168.0.0/16 \
--etcd_servers=http://127.0.0.1:4001 \
--v=3 \
--logtostderr=false \
--log_dir=./log &
