#!/bin/bash

#start etcd
nohup /opt/etcd-v2.2.2-linux-amd64/etcd &

export PATH=$PATH:/opt/kubernetes/_output/local/go/bin
#start kubernetes
nohup bash star_apiserver.sh &
nohup bash start_controller-manager.sh &
nohup bash start_scheduler.sh &
nohup bash start_kubelet.sh &
